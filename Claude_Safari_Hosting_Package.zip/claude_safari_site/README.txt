CLAUDE-STYLE CHAT — SAFARI HOSTING PACKAGE

This package contains your original Claude.html renamed to index.html so a static website host can serve it as the homepage.

NO APP OR PYTHON INSTALL IS REQUIRED ON YOUR IPHONE.

To make it open as a normal Safari link using GitHub Pages:
1. In Safari, go to https://github.com and sign in.
2. Open the repository where you want to host this page (or create a new public repository).
3. Upload index.html from this package to the repository's top level (root).
4. In the repository, open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. The Pages screen will show the live website URL. Open that URL in Safari.

NOTES
- This package preserves the supplied HTML; it does not change the app's code or appearance.
- The page loads Puter.js from its external CDN, so internet access is required.
- Sign-in, model access, and usage depend on Puter's current service and account requirements.
- A live website has not been published by this package; GitHub Pages must be enabled in your account first.
